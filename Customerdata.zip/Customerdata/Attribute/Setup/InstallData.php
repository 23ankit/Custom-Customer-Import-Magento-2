<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Customerdata\Attribute\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Customer\Model\Customer;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;


class InstallData implements InstallDataInterface
{
	/**
     * @var CustomerSetupFactory
     */
    protected $customerSetupFactory;
    
    /**
     * @var AttributeSetFactory
     */
    private $attributeSetFactory;
	
	private $eavSetupFactory; 

    /**
     * Init
     *
     * @param EavSetupFactory $eavSetupFactory
     */
    public function __construct(EavSetupFactory $eavSetupFactory, CustomerSetupFactory $customerSetupFactory, AttributeSetFactory $attributeSetFactory)
    {
		$this->eavSetupFactory = $eavSetupFactory;
		$this->customerSetupFactory = $customerSetupFactory;
        $this->attributeSetFactory = $attributeSetFactory;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {

		/* Create customer attribute is_builder_account for front-end builder*/
		/** @var CustomerSetup $customerSetup */
        $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);
        
        $customerEntity = $customerSetup->getEavConfig()->getEntityType('customer');
        $attributeSetId = $customerEntity->getDefaultAttributeSetId();
        
        /** @var $attributeSet AttributeSet */
        $attributeSet = $this->attributeSetFactory->create();
        $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);
        

// SELECT 

        $customerSetup->addAttribute(Customer::ENTITY, 'afm_isspammable', [
            'type' => 'int',
            'label' => 'AFM ISSPAMMABLE',
            'input' => 'select',
            'required' => false,
            'visible' => true,
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            'sort_order' => 1002,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1002,
            'default' => 0,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_isspammable')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);

$customerSetup->addAttribute(Customer::ENTITY, 'afm_ismobile', [
            'type' => 'int',
            'label' => 'AFM ISMOBILE',
            'input' => 'select',
            'required' => false,
            'visible' => true,
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            'sort_order' => 1003,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1003,
            'default' => 0,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_ismobile')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'afm_isactive', [
            'type' => 'int',
            'label' => 'AFM ISACTIVE',
            'input' => 'select',
            'required' => false,
            'visible' => true,
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            'sort_order' => 1004,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1004,
            'default' => 0,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_isactive')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);


        $customerSetup->addAttribute(Customer::ENTITY, 'afm_isregistered', [
            'type' => 'int',
            'label' => 'AFM ISREGISTERED',
            'input' => 'select',
            'required' => false,
            'visible' => true,
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            'sort_order' => 1005,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1005,
            'default' => 0,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_isregistered')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);



        $customerSetup->addAttribute(Customer::ENTITY, 'afm_isvalidated', [
            'type' => 'int',
            'label' => 'AFM ISVALIDATED',
            'input' => 'select',
            'required' => false,
            'visible' => true,
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            'sort_order' => 1006,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1006,
            'default' => 0,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_isvalidated')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'afm_isphotocontestsignup', [
            'type' => 'int',
            'label' => 'AFM ISPHOTOCONTESTSIGNUP',
            'input' => 'select',
            'required' => false,
            'visible' => true,
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            'sort_order' => 1007,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1007,
            'default' => 0,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_isphotocontestsignup')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);


        $customerSetup->addAttribute(Customer::ENTITY, 'afm_registeredwithfacebook', [
            'type' => 'int',
            'label' => 'AFM REGISTEREDWITHFACEBOOK',
            'input' => 'select',
            'required' => false,
            'visible' => true,
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            'sort_order' => 1008,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1008,
            'default' => 0,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_registeredwithfacebook')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);    


        $customerSetup->addAttribute(Customer::ENTITY, 'afm_linkedtofacebook', [
            'type' => 'int',
            'label' => 'AFM LINKEDTOFACEBOOK',
            'input' => 'select',
            'required' => false,
            'visible' => true,
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            'sort_order' => 1009,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1009,
            'default' => 0,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_linkedtofacebook')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'afm_mustconfirmtaxexempt', [
            'type' => 'int',
            'label' => 'AFM MUSTCONFIRMTAXEXEMPT',
            'input' => 'select',
            'required' => false,
            'visible' => true,
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            'sort_order' => 1010,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1010,
            'default' => 0,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_mustconfirmtaxexempt')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'afm_isvip', [
            'type' => 'int',
            'label' => 'AFM ISVIP',
            'input' => 'select',
            'required' => false,
            'visible' => true,
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            'sort_order' => 1011,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1011,
            'default' => 0,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_isvip')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]); 


        $customerSetup->addAttribute(Customer::ENTITY, 'afm_user_imported', [
            'type' => 'int',
            'label' => 'AFM USER IMPORTED',
            'input' => 'select',
            'required' => false,
            'visible' => true,
            'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            'sort_order' => 1012,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1012,
            'default' => 0,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_user_imported')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]); 

// SELECT

// INPUT



        $customerSetup->addAttribute(Customer::ENTITY, 'afm_comisvip', [
            'type' => 'varchar',
            'label' => 'AFM COMISVIP',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'sort_order' => 1013,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1013,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_comisvip')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'afm_comtitle', [
            'type' => 'varchar',
            'label' => 'AFM COMTITLE',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'sort_order' => 1014,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1014,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_comtitle')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'afm_comid', [
            'type' => 'varchar',
            'label' => 'AFM COMID',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'sort_order' => 1015,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1015,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_comid')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'afm_accountnumber', [
            'type' => 'varchar',
            'label' => 'AFM ACCOUNTNUMBER',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'sort_order' => 1016,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1016,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_accountnumber')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);


        $customerSetup->addAttribute(Customer::ENTITY, 'afm_wphone', [
            'type' => 'varchar',
            'label' => 'AFM WPHONE',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'sort_order' => 1017,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1017,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_wphone')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'afm_hphone', [
            'type' => 'varchar',
            'label' => 'AFM HPHONE',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'sort_order' => 1018,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1018,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_hphone')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);

        $customerSetup->addAttribute(Customer::ENTITY, 'afm_id', [
            'type' => 'varchar',
            'label' => 'AFM ID',
            'input' => 'text',
            'required' => false,
            'visible' => true,
            'sort_order' => 1019,
            'is_filterable_in_grid' => 1,
            'is_searchable_in_grid' => 1,
            'is_user_defined' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'position' => 1019,
            'system' => 0,
        ]);
        
        $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'afm_id')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer'],
        ]);

// INPUT





        $attribute->save();
		
		
    }
}
