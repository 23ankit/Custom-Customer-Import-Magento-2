<?php

namespace Customerdata\Import\Controller\Adminhtml\Import;
use Magento\Framework\Json\EncoderInterface;
use Magento\Framework\App\Filesystem\DirectoryList;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_filesystem;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\App\Config\ConfigResource\ConfigInterface
     */
    protected $_configResource;

    /**
     * @param \Magento\Backend\App\Action\Context                          $context           
     * @param \Magento\Framework\View\Result\PageFactory                   $resultPageFactory 
     * @param \Lof\Setup\Helper\Import                                     $lofImport           
     * @param \Magento\Framework\Filesystem                                $filesystem        
     * @param \Magento\Store\Model\StoreManagerInterface                   $storeManager      
     * @param \Magento\Framework\App\Config\ScopeConfigInterface           $scopeConfig       
     * @param \Magento\Framework\App\ResourceConnection                    $resource          
     * @param \Magento\Framework\App\Config\ConfigResource\ConfigInterface $configResource
     * @param \Magento\Catalog\Model\Product\Media\Config $mediaConfig    
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Framework\App\Config\ConfigResource\ConfigInterface $configResource,
        \Magento\Catalog\Model\Product\Media\Config $mediaConfig
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->_filesystem       = $filesystem;
        $this->_storeManager     = $storeManager;
        $this->_scopeConfig      = $scopeConfig;
        $this->_configResource   = $configResource;
        $this->_resource         = $resource;
        $this->mediaConfig       = $mediaConfig;
    }

    /**
     * Forward to edit
     *
     * @return \Magento\Backend\Model\View\Result\Forward
     */
    public function readCSV($csvFile){
        $file_handle = fopen($csvFile, 'r');
        while (!feof($file_handle) ) {
            $line_of_text[] = fgetcsv($file_handle, 1024);
        }
        fclose($file_handle);
        return $line_of_text;
    }

    public function execute()
    {
        $data = $this->getRequest()->getParams();
   

          


$statearray = array(
  'AL' => 'Alabama',
  'AK' => 'Alaska',
  'AZ' => 'Arizona',
  'AR' => 'Arkansas',
  'CA' => 'California',
  'CO' => 'Colorado',
  'CT' => 'Connecticut',
  'DE' => 'Delaware',
  'DC' => 'District Of Columbia',
  'FL' => 'Florida',
  'GA' => 'Georgia',
  'HI' => 'Hawaii',
  'ID' => 'Idaho',
  'IL' => 'Illinois',
  'IN' => 'Indiana',
  'IA' => 'Iowa',
  'KS' => 'Kansas',
  'KY' => 'Kentucky',
  'LA' => 'Louisiana',
  'ME' => 'Maine',
  'MD' => 'Maryland',
  'MA' => 'Massachusetts',
  'MI' => 'Michigan',
  'MN' => 'Minnesota',
  'MS' => 'Mississippi',
  'MO' => 'Missouri',
  'MT' => 'Montana',
  'NE' => 'Nebraska',
  'NV' => 'Nevada',
  'NH' => 'New Hampshire',
  'NJ' => 'New Jersey',
  'NM' => 'New Mexico',
  'NY' => 'New York',
  'NC' => 'North Carolina',
  'ND' => 'North Dakota',
  'OH' => 'Ohio',
  'OK' => 'Oklahoma',
  'OR' => 'Oregon',
  'PA' => 'Pennsylvania',
  'RI' => 'Rhode Island',
  'SC' => 'South Carolina',
  'SD' => 'South Dakota',
  'TN' => 'Tennessee',
  'TX' => 'Texas',
  'UT' => 'Utah',
  'VT' => 'Vermont',
  'VA' => 'Virginia',
  'WA' => 'Washington',
  'WV' => 'West Virginia',
  'WI' => 'Wisconsin',
  'WY' => 'Wyoming',
); 

 
    
    if(isset($_FILES["data_import_file"])){
    if ($_FILES["data_import_file"]["size"] > 0) {
$fileName = $_FILES["data_import_file"]["tmp_name"];

$csv = $this->readCSV($fileName);
    if(count($csv) > 1000){
        $this->messageManager->addError(__("please upload CSV with less then 1000 records."));
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/*/');
    }
    

        $file = fopen($fileName, "r");
        $i = 0;
        while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
         
         if(count($column) <= 34){
          if($i > 0){ 
          $MEMID = isset($column[0])?$column[0]:'';
          $MEMNAMEPREFIX = isset($column[1])?$column[1]:'';
          $MEMFNAME = (isset($column[2])  && $column[2]!="")?$column[2]:'.';
          $MEMLNAME = (isset($column[3])  && $column[3]!="")?$column[3]:'.';
          $MEMCOMPANY = isset($column[4])?$column[4]:'';
          $MEMADDRESS1 =  (isset($column[5])  && $column[5]!="")?$column[5]:'.';
          $MEMADDRESS2 = isset($column[6])?$column[6]:'';
          $street = $MEMADDRESS1."\r\n".$MEMADDRESS2;
          $MEMCITY = (isset($column[7])  && $column[7]!="")?$column[7]:'.';
          $MEMSTATE = isset($column[8])?$column[8]:''; 
          $MEMZIP = (isset($column[9])  && $column[9]!="")?$column[9]:'.';
          $MEMCOUNTRY = (isset($column[10])  && $column[10]!="")?$column[10]:'US';
          if(array_key_exists(strtoupper($MEMSTATE),$statearray))
          {
              $state = $statearray[strtoupper($MEMSTATE)];
          }else{
              $state = $MEMSTATE;
          }
          $regionCode = strtoupper($MEMSTATE);
          $countryCode = $MEMCOUNTRY;
          $region = $this->_objectManager->create('Magento\Directory\Model\Region');
          $regionId = $region->loadByCode($regionCode, $countryCode)->getId();
          $MEMHPHONE = isset($column[11])?$column[11]:'';
          $MEMWPHONE = isset($column[12])?$column[12]:'';
          $MEMEMAIL = isset($column[13])?$column[13]:'';
          $MEMPETALS = isset($column[14])?$column[14]:'';
          $MEMISSPAMMABLEs = isset($column[15])?$column[15]:'';
          if($MEMISSPAMMABLEs == 'true'){
            $MEMISSPAMMABLE = 1;
          }else{
            $MEMISSPAMMABLE = 0;
          }
          $MEMISACTIVEs = isset($column[16])?$column[16]:'';
          if($MEMISACTIVEs == 'true'){
            $MEMISACTIVE = 1;
          }else{
            $MEMISACTIVE = 0;
          }

          $MEMISMOBILEs = isset($column[17])?$column[17]:'';

          if($MEMISMOBILEs == 'true'){
            $MEMISMOBILE = 1;
          }else{
            $MEMISMOBILE = 0;
          }

          $MEMDATESTAMP = isset($column[18])?$column[18]:'';
          $MEMBIRTHDAY = isset($column[19])?$column[19]:'';
          $birthday = date('d-m-Y',strtotime($MEMBIRTHDAY));
          $MEMISVALIDATEDs = isset($column[20])?$column[20]:'';
          if($MEMISVALIDATEDs == 'true'){
            $MEMISVALIDATED = 1;
          }else{
            $MEMISVALIDATED = 0;
          }

          $MEMISPHOTOCONTESTSIGNUPs = isset($column[21])?$column[21]:'';
          if($MEMISPHOTOCONTESTSIGNUPs == 'true'){
            $MEMISPHOTOCONTESTSIGNUP =1;
          }else{
            $MEMISPHOTOCONTESTSIGNUP = 0;
          }

          $MEMGENDER = isset($column[22])?$column[22]:'';
          if($MEMGENDER == 'F'){$gender = 2;}else if($MEMGENDER == 'M'){$gender = 1;}else{$gender = '';}
          $MEMISREGISTEREDs = isset($column[23])?$column[23]:'';
          if($MEMISREGISTEREDs == 'true'){
            $MEMISREGISTERED = 1;
          }else{
            $MEMISREGISTERED = 0;
          }

          $MEMREGISTEREDWITHFACEBOOKs = isset($column[24])?$column[24]:'';
          if($MEMREGISTEREDWITHFACEBOOKs == 'true'){
            $MEMREGISTEREDWITHFACEBOOK = 1;
          }else{
            $MEMREGISTEREDWITHFACEBOOK = 0;
          }

          $MEMLINKEDTOFACEBOOKs = isset($column[25])?$column[25]:'';

          if($MEMLINKEDTOFACEBOOKs == 'true'){
            $MEMLINKEDTOFACEBOOK = 1;
          }else{
            $MEMLINKEDTOFACEBOOK = 0;
          }

          $MEMTAXID = isset($column[26])?$column[26]:'';
          $MEMMUSTCONFIRMTAXEXEMPTs = isset($column[27])?$column[27]:'';

          if($MEMMUSTCONFIRMTAXEXEMPTs == 'true'){
            $MEMMUSTCONFIRMTAXEXEMPT = 1;
          }else{
            $MEMMUSTCONFIRMTAXEXEMPT = 0;
          }

          $MEMISVIPs = isset($column[28])?$column[28]:'';

          if($MEMISVIPs == 'true'){
            $MEMISVIP = 1;
          }else{
            $MEMISVIP = 0;
          }

          $MEMACCOUNTNUMBER = isset($column[29])?$column[29]:'';
          $COMID = isset($column[30])?$column[30]:'';
          $COMTITLE = isset($column[31])?$column[31]:'';
          $COMISVIP = isset($column[32])?$column[32]:'';


          $storeManager = $this->_objectManager->get('\Magento\Store\Model\StoreManagerInterface');
  
        // Customer Factory to Create Customer
        $customerFactory = $this->_objectManager->get('\Magento\Customer\Model\CustomerFactory');
 

        $customer_check = $this->_objectManager->get('Magento\Customer\Model\Customer');
        $websiteId = $storeManager->getWebsite()->getWebsiteId();
        $customer_check->setWebsiteId($websiteId);
        $customer_check->loadByEmail($MEMEMAIL);
        if (empty($customer_check->getId())) {
              
         
        
          try{
         
          $customer = $customerFactory->create();
          $customer->setWebsiteId($websiteId);
          $customer->setEmail($MEMEMAIL);
          $customer->setDob($birthday);
          $customer->setGender($gender); //1 Male 2 Female
          $customer->setFirstname($MEMFNAME);
          $customer->setLastname($MEMLNAME);
          $customer->setTaxvat($MEMTAXID);
          $customer->setAfmIsspammable($MEMISSPAMMABLE);
          $customer->setAfmIsmobile($MEMISMOBILE);
          $customer->setAfmIsactive($MEMISACTIVE);
          $customer->setAfmIsregistered($MEMISREGISTERED);
          $customer->setAfmIsvalidated($MEMISVALIDATED);
          $customer->setAfmIsphotocontestsignup($MEMISPHOTOCONTESTSIGNUP);
          $customer->setAfmRegisteredwithfacebook($MEMREGISTEREDWITHFACEBOOK);
          $customer->setAfmLinkedtofacebook($MEMLINKEDTOFACEBOOK);
          $customer->setAfmMustconfirmtaxexempt($MEMMUSTCONFIRMTAXEXEMPT);
          $customer->setAfmIsvip($MEMISVIP);
          $customer->setAfmUserImported(1);
          $customer->setAfmComisvip($COMISVIP);
          $customer->setAfmComtitle($COMTITLE);
          $customer->setAfmComid($COMID);
          $customer->setAfmAccountnumber($MEMACCOUNTNUMBER);
          $customer->setAfmWphone($MEMWPHONE);
          $customer->setAfmHphone($MEMHPHONE);
          $customer->setAfmId($MEMID);
          $customer->setPassword('123456789');
          $customer->save();    
          /********Send email to customer********/
          //$customer->sendNewAccountEmail();
          
          /******** See the customer Id*****/

          //echo 'Create customer successfully'.$customer->getId();
          $customer_id = $customer->getId();
          }catch(Exception $e){
          echo $e->getMessage();
          }
$postcode_array = array();
}else{
$customer_id = $customer_check->getId();
$customerId = $customer_id;
$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
$customerObj = $objectManager->create('Magento\Customer\Model\Customer')->load($customerId);
$customerAddress = array();
$postcode_array = array();
foreach ($customerObj->getAddresses() as $address)
{
    $customerAddress[] = $address->toArray();
}

foreach ($customerAddress as $customerAddres) {

    $postcode_array[] = $customerAddres['postcode'];
}



}




        if(!in_array($MEMZIP, $postcode_array)){
          

        $addresss = $this->_objectManager->get('\Magento\Customer\Model\AddressFactory');
        
        try{

          $address = $addresss->create();

          $address->setCustomerId($customer_id)

          ->setPrefix($MEMNAMEPREFIX)

          ->setFirstname($MEMFNAME)

          ->setLastname($MEMLNAME)

          ->setCountryId($MEMCOUNTRY)

          ->setPostcode($MEMZIP)

          ->setCity($MEMCITY)

          ->setRegionId($regionId)

          ->setTelephone($MEMHPHONE)

          ->setFax('')

          ->setCompany($MEMCOMPANY)

          ->setStreet($street)

          ->setIsDefaultBilling('1')

          ->setIsDefaultShipping('1')

          ->setSaveInAddressBook('1');

          $address->save();
          }catch(Exception $e){
            $e->getMessage();
        }
        }
                 
      /*                if (! empty($result)) {
                          $type = "success";
                          $message = "CSV Data Imported into the Database";
                      } else {
                          $type = "error";
                          $message = "Problem in Importing CSV Data";
                      }*/
                  }
                  }else{
                      $this->messageManager->addError(__("Please Check csv Column"));
                      $resultRedirect = $this->resultRedirectFactory->create();
                      return $resultRedirect->setPath('*/*/');
                  }
              $i++; }
          $this->messageManager->addSuccess(__("Import successfully"));
          }else{
            $this->messageManager->addError(__("Please Upload Customer CSV!!"));
          }

 
        }
            
        

    $resultRedirect = $this->resultRedirectFactory->create();
    return $resultRedirect->setPath('*/*/');
    }
}
